import email from "../../assets/email.png";

export default function ClassDetails({ detail, className }) {
  const { pfp, name, cabin, timeSlot } = detail;

  return (
    <article className={`faculty-card ${className}`}>
      <img src={pfp} alt="faculty-pfp" className="faculty-pfp" />
      <div className="faculty-name-cabin">
        <p className="faculty-name">{name}</p>
        <p className="faculty-cabin">Cabin - {cabin}</p>
      </div>
      <img src={email} alt="faculty-mail" className="faculty-mail" />
      <div className="faculty-timeSlot-container">
        <p className="faculty-timeSlot">Time Slot</p>
        <p className="faculty-time">{timeSlot}</p>
      </div>
      <button className="faculty-contact">Contact</button>
    </article>
  );
}
